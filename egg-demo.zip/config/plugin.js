exports.nunjucks = {
  enable: true,
  package: "egg-view-nunjucks",
};
