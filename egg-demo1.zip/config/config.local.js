exports.security = {
  csrf: {
    enable: false,
  },
};
