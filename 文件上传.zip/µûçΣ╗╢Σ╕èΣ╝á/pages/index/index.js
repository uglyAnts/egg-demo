const app = getApp()

Page({
  data: {

  },
  onLoad() {
 
  },
})
